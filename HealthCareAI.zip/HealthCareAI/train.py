"""
train.py  -  STEP 1: clean the data, explore it, train and compare models.
Run:  python train.py
Creates: model.pkl, train_split.csv, test_split.csv, results/*.png, results/*.csv
"""
import warnings
warnings.filterwarnings("ignore")

import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.patches import FancyBboxPatch

from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score
from sklearn.model_selection import GridSearchCV, GroupKFold, GroupShuffleSplit, cross_val_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier

sns.set_style("whitegrid")
TARGET = "Medical Condition"
CATEGORICAL = ["Gender", "Blood Type", "Insurance Provider", "Admission Type",
               "Medication", "Test Results"]
NUMERIC = ["Age", "Billing Amount", "Length of Stay", "Admission Month"]
FEATURES = CATEGORICAL + NUMERIC


def show(title, table):
    print(f"\n=== {title} ===")
    print(table.to_string(index=False))
    table.to_csv("results/" + title.lower().replace(" ", "_").replace("/", "_") + ".csv", index=False)


def savefig(name):
    plt.tight_layout()
    plt.savefig(f"results/{name}", dpi=110, bbox_inches="tight")
    plt.close()
    print(f"[Chart saved] results/{name}")


# ============================================================ 1. LOAD + CLEAN
raw = pd.read_csv("healthcare_dataset.csv")
df, log = raw.copy(), [("Rows in raw file", len(raw))]

df["Name"] = df["Name"].str.strip().str.title()
df = df.drop_duplicates();                                   log.append(("After removing exact duplicates", len(df)))
df = df.drop_duplicates(subset=["Name", "Blood Type", TARGET, "Date of Admission", "Billing Amount"])
log.append(("After removing near-duplicates", len(df)))
df = df[df["Billing Amount"] > 0];                           log.append(("After removing negative bills", len(df)))
df["Date of Admission"] = pd.to_datetime(df["Date of Admission"])
df["Discharge Date"] = pd.to_datetime(df["Discharge Date"])
df["Length of Stay"] = (df["Discharge Date"] - df["Date of Admission"]).dt.days
df["Admission Month"] = df["Date of Admission"].dt.month
df = df.reset_index(drop=True)
df.to_csv("healthcare_clean.csv", index=False)

show("Cleaning Log", pd.DataFrame(log, columns=["step", "rows"]))
show("Dataset Overview", pd.DataFrame({
    "column": raw.columns, "type": raw.dtypes.astype(str).values,
    "unique values": [raw[c].nunique() for c in raw.columns],
    "missing": raw.isnull().sum().values}))
show("Numeric Summary", df[["Age", "Billing Amount", "Length of Stay"]].describe()
     .round(2).reset_index().rename(columns={"index": "statistic"}))

cond = df[TARGET].value_counts().reset_index()
cond.columns = [TARGET, "admissions"]
cond["% of total"] = (cond["admissions"] / cond["admissions"].sum() * 100).round(2)
cond["avg billing"] = cond[TARGET].map(df.groupby(TARGET)["Billing Amount"].mean().round(2))
show("Class Distribution", cond)

# ================================================================ 2. DIAGRAMS
# 2a. Project workflow diagram
fig, ax = plt.subplots(figsize=(15, 3.2)); ax.axis("off")
steps = ["Healthcare\ndataset", "Clean data", "Explore\n(EDA)", "Split by\npatient",
         "Train\nmodels", "Test on\nunseen data", "Predict\n(app / CLI)"]
for i, s in enumerate(steps):
    x = i * 2.05
    ax.add_patch(FancyBboxPatch((x, 0.2), 1.7, 1.0, boxstyle="round,pad=0.05",
                                fc="#1F3A5F" if i in (4, 5, 6) else "#4C72B0", ec="none"))
    ax.text(x + 0.85, 0.7, s, ha="center", va="center", color="white", fontsize=11, fontweight="bold")
    if i < len(steps) - 1:
        ax.annotate("", xy=(x + 2.0, 0.7), xytext=(x + 1.75, 0.7),
                    arrowprops=dict(arrowstyle="->", lw=2, color="#333"))
ax.set_xlim(-0.2, len(steps) * 2.05); ax.set_ylim(0, 1.4)
ax.set_title("HealthCareAI Workflow", fontsize=14, fontweight="bold")
savefig("diagram_workflow.png")

# 2b. EDA charts
fig, ax = plt.subplots(2, 3, figsize=(18, 10))
cond.set_index(TARGET)["admissions"].sort_values().plot.barh(ax=ax[0, 0], color="#4C72B0")
ax[0, 0].set_title("Admissions per Medical Condition"); ax[0, 0].set_ylabel("")
cond.set_index(TARGET)["avg billing"].sort_values().plot.barh(ax=ax[0, 1], color="#DD8452")
ax[0, 1].set_title("Average Billing per Condition"); ax[0, 1].set_ylabel("")
sns.histplot(df["Age"], bins=30, kde=True, ax=ax[0, 2], color="#55A868"); ax[0, 2].set_title("Age Distribution")
sns.histplot(df["Billing Amount"], bins=40, kde=True, ax=ax[1, 0], color="#C44E52"); ax[1, 0].set_title("Billing Amount Distribution")
df["Admission Type"].value_counts().plot.pie(ax=ax[1, 1], autopct="%1.1f%%"); ax[1, 1].set_ylabel(""); ax[1, 1].set_title("Admission Type")
sns.heatmap(df[["Age", "Billing Amount", "Length of Stay"]].corr(), annot=True, fmt=".2f",
            cmap="coolwarm", center=0, ax=ax[1, 2]); ax[1, 2].set_title("Correlation (numeric fields)")
savefig("eda.png")

fig, ax = plt.subplots(1, 2, figsize=(15, 5.5))
sns.countplot(data=df, y=TARGET, hue="Gender", ax=ax[0], palette="Set2"); ax[0].set_title("Condition by Gender")
sns.boxplot(data=df, x=TARGET, y="Billing Amount", ax=ax[1], palette="Set3")
ax[1].set_title("Billing by Condition"); plt.setp(ax[1].get_xticklabels(), rotation=25)
savefig("eda_condition_details.png")

# ================================================================ 3. SPLIT
splitter = GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=42)
tr, te = next(splitter.split(df, groups=df["Name"]))       # same patient never in both
train_df, test_df = df.loc[tr], df.loc[te]
train_df.to_csv("train_split.csv", index=False)
test_df.to_csv("test_split.csv", index=False)
show("Train Test Split", pd.DataFrame({"split": ["train", "test"],
                                       "rows": [len(train_df), len(test_df)],
                                       "%": [80, 20]}))
X_train, y_train = train_df[FEATURES], train_df[TARGET]
X_test, y_test = test_df[FEATURES], test_df[TARGET]


def pipeline(clf):
    prep = ColumnTransformer([("cat", OneHotEncoder(handle_unknown="ignore"), CATEGORICAL),
                              ("num", StandardScaler(), NUMERIC)])
    return Pipeline([("prep", prep), ("clf", clf)])


# ================================================================ 4. TRAIN
grid = GridSearchCV(
    pipeline(RandomForestClassifier(random_state=42, n_jobs=-1)),
    {"clf__n_estimators": [100, 200], "clf__max_depth": [6, 10, None],
     "clf__min_samples_leaf": [5, 15]},
    cv=GroupKFold(n_splits=3), scoring="accuracy")
print("\nTuning Random Forest ...")
grid.fit(X_train, y_train, groups=train_df["Name"])
best_rf = grid.best_estimator_
show("Best Hyperparameters", pd.DataFrame(list(grid.best_params_.items()),
                                          columns=["parameter", "value"]))

candidates = {
    "Baseline (most common class)": DummyClassifier(strategy="most_frequent"),
    "Logistic Regression": LogisticRegression(max_iter=1000),
    "Decision Tree": DecisionTreeClassifier(max_depth=8, min_samples_leaf=20, random_state=42),
    "Random Forest (tuned)": None,
}
rows = []
for name, clf in candidates.items():
    m = best_rf if clf is None else pipeline(clf).fit(X_train, y_train)
    p_tr, p_te = m.predict(X_train), m.predict(X_test)
    rows.append({"model": name,
                 "train accuracy": round(accuracy_score(y_train, p_tr), 4),
                 "test accuracy": round(accuracy_score(y_test, p_te), 4),
                 "test macro F1": round(f1_score(y_test, p_te, average="macro"), 4)})
comparison = pd.DataFrame(rows)
show("Model Comparison", comparison)

plt.figure(figsize=(10, 4.5))
melt = comparison.melt(id_vars="model", value_vars=["train accuracy", "test accuracy"])
sns.barplot(data=melt, x="value", y="model", hue="variable", palette="Set2")
plt.axvline(1 / y_train.nunique(), color="red", ls="--", label="Chance (1/6)")
plt.xlim(0, 1); plt.legend(loc="lower right"); plt.xlabel("Accuracy"); plt.ylabel("")
plt.title("Model Comparison - Train vs Test Accuracy", fontweight="bold")
savefig("model_comparison.png")

# cross-validation (grouped by patient)
cv = cross_val_score(best_rf, df[FEATURES], df[TARGET], groups=df["Name"], cv=GroupKFold(n_splits=5))
show("Cross Validation", pd.DataFrame({"fold": range(1, 6), "accuracy": cv.round(4)}))
print(f"Mean CV accuracy: {cv.mean():.4f} (+/- {cv.std():.4f})")
plt.figure(figsize=(7, 4))
sns.barplot(x=[f"Fold {i}" for i in range(1, 6)], y=cv, palette="viridis")
plt.axhline(cv.mean(), color="red", ls="--", label=f"Mean = {cv.mean():.4f}")
plt.ylim(0, 0.4); plt.ylabel("Accuracy"); plt.legend(); plt.title("5-Fold Cross-Validation", fontweight="bold")
savefig("cv_scores.png")

# feature importance
names = [n.split("__", 1)[1] for n in best_rf.named_steps["prep"].get_feature_names_out()]
imp = pd.DataFrame({"feature": names, "importance": best_rf.named_steps["clf"].feature_importances_})
imp = imp.sort_values("importance", ascending=False).head(15)
show("Top Feature Importances", imp.round(4))
plt.figure(figsize=(9, 6))
plt.barh(imp["feature"][::-1], imp["importance"][::-1], color="#4C72B0")
plt.title("Top 15 Feature Importances", fontweight="bold")
savefig("feature_importance.png")

joblib.dump(best_rf, "model.pkl")
print("\nModel saved: model.pkl   -> next run: python test.py")
