"""
predict.py  -  STEP 3: use the trained model to predict a patient's condition.
Run:  python predict.py                 demo: 5 sample patients + probability table
      python predict.py file.csv        batch: predict every row of a CSV (same columns as the dataset)
      python predict.py --interactive   type one patient in
"""
import sys
import warnings
warnings.filterwarnings("ignore")

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

TARGET = "Medical Condition"
FEATURES = ["Gender", "Blood Type", "Insurance Provider", "Admission Type", "Medication",
            "Test Results", "Age", "Billing Amount", "Length of Stay", "Admission Month"]
model = joblib.load("model.pkl")


def add_features(df):
    """Adds Length of Stay / Admission Month if the CSV only has the original columns."""
    df = df.copy()
    if "Length of Stay" not in df:
        df["Length of Stay"] = (pd.to_datetime(df["Discharge Date"]) - pd.to_datetime(df["Date of Admission"])).dt.days
    if "Admission Month" not in df:
        df["Admission Month"] = pd.to_datetime(df["Date of Admission"]).dt.month
    return df


def predict(df):
    proba = model.predict_proba(df[FEATURES])
    out = df.copy()
    out["Predicted"] = model.classes_[proba.argmax(axis=1)]
    out["Confidence"] = proba.max(axis=1).round(4)
    return out, proba


def show_probabilities(proba_row, title):
    table = pd.DataFrame({"Condition": model.classes_, "Probability": (proba_row * 100).round(1)})
    table = table.sort_values("Probability", ascending=False)
    print(f"\n{title}\n" + table.to_string(index=False))
    return table


if len(sys.argv) > 1 and sys.argv[1] == "--interactive":
    row = pd.DataFrame([{
        "Age": int(input("Age: ")), "Gender": input("Gender (Male/Female): ").title(),
        "Blood Type": input("Blood type (e.g. A+): ").upper(),
        "Insurance Provider": input("Insurance provider: "),
        "Admission Type": input("Admission type (Elective/Emergency/Urgent): ").title(),
        "Medication": input("Medication: ").title(), "Test Results": input("Test result (Normal/Abnormal/Inconclusive): ").title(),
        "Billing Amount": float(input("Billing amount: ")), "Length of Stay": int(input("Length of stay (days): ")),
        "Admission Month": int(input("Admission month (1-12): "))}])
    out, proba = predict(row)
    print(f"\nPredicted condition: {out['Predicted'][0]}  (confidence {out['Confidence'][0]:.1%})")
    show_probabilities(proba[0], "Probabilities")

elif len(sys.argv) > 1:
    df = add_features(pd.read_csv(sys.argv[1]))
    out, _ = predict(df)
    out.to_csv("results/predictions.csv", index=False)
    cols = [c for c in ["Name", TARGET, "Predicted", "Confidence"] if c in out]
    print(out[cols].head(20).to_string(index=False))
    print("\nAll predictions saved: results/predictions.csv")

else:
    sample = pd.read_csv("test_split.csv").sample(5, random_state=7)
    out, proba = predict(sample)
    out["Correct"] = (out[TARGET] == out["Predicted"]).map({True: "Yes", False: "No"})
    print("=== Demo: 5 patients from the unseen test set ===")
    print(out[["Name", "Age", "Gender", "Medication", TARGET, "Predicted", "Confidence", "Correct"]].to_string(index=False))
    tbl = show_probabilities(proba[0], f"Probabilities for {out['Name'].iloc[0]}")
    plt.figure(figsize=(7, 4))
    plt.barh(tbl["Condition"][::-1], tbl["Probability"][::-1], color="#4C72B0")
    plt.xlabel("Probability (%)"); plt.title(f"Prediction for {out['Name'].iloc[0]}", fontweight="bold")
    plt.tight_layout(); plt.savefig("results/predict_example.png", dpi=110); plt.close()
    out.to_csv("results/predictions_demo.csv", index=False)
    print("\n[Chart saved] results/predict_example.png")
