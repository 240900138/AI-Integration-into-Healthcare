"""HealthCareAI web app.  Run:  streamlit run app.py   (after train.py and test.py)"""
import joblib
import pandas as pd
import streamlit as st

st.set_page_config(page_title="HealthCareAI", layout="wide")
st.title("HealthCareAI - Healthcare Admissions")

df = pd.read_csv("healthcare_clean.csv")
model = joblib.load("model.pkl")
R = "results/"

tab1, tab2, tab3 = st.tabs(["Dashboard", "Predict", "Model Results"])

with tab1:
    c1, c2, c3 = st.columns(3)
    c1.metric("Admissions", f"{len(df):,}")
    c2.metric("Average bill", f"${df['Billing Amount'].mean():,.0f}")
    c3.metric("Average stay (days)", f"{df['Length of Stay'].mean():.1f}")
    a, b = st.columns(2)
    a.subheader("Admissions per condition")
    a.bar_chart(df["Medical Condition"].value_counts())
    b.subheader("Average bill per condition")
    b.bar_chart(df.groupby("Medical Condition")["Billing Amount"].mean())
    st.image(R + "eda.png")

with tab2:
    c1, c2, c3 = st.columns(3)
    age = c1.number_input("Age", 0, 120, 45)
    gender = c1.selectbox("Gender", sorted(df["Gender"].unique()))
    blood = c1.selectbox("Blood type", sorted(df["Blood Type"].unique()))
    insurer = c2.selectbox("Insurance", sorted(df["Insurance Provider"].unique()))
    adm = c2.selectbox("Admission type", sorted(df["Admission Type"].unique()))
    med = c2.selectbox("Medication", sorted(df["Medication"].unique()))
    result = c3.selectbox("Test result", sorted(df["Test Results"].unique()))
    bill = c3.number_input("Billing amount", 0.0, 100000.0, 25000.0)
    stay = c3.number_input("Length of stay (days)", 1, 60, 10)
    if st.button("Predict", type="primary"):
        row = pd.DataFrame([{"Gender": gender, "Blood Type": blood,
                             "Insurance Provider": insurer, "Admission Type": adm,
                             "Medication": med, "Test Results": result, "Age": age,
                             "Billing Amount": bill, "Length of Stay": stay,
                             "Admission Month": 6}])
        proba = model.predict_proba(row)[0]
        top = pd.DataFrame({"Condition": model.classes_, "Probability": proba})
        top = top.sort_values("Probability", ascending=False)
        st.success(f"Most likely condition: **{top.iloc[0]['Condition']}**")
        st.bar_chart(top.set_index("Condition"))
        st.table(top.style.format({"Probability": "{:.1%}"}))
        st.caption("Decision support only - not a diagnosis.")

with tab3:
    st.subheader("Model comparison")
    st.table(pd.read_csv(R + "model_comparison.csv"))
    st.image(R + "model_comparison.png")
    st.subheader("Test set results (unseen patients)")
    st.table(pd.read_csv(R + "test_metrics.csv"))
    st.table(pd.read_csv(R + "classification_report.csv"))
    st.image(R + "test_confusion_matrix.png")
    st.image(R + "test_per_class_scores.png")
    st.image(R + "feature_importance.png")
    st.info("Accuracy is close to chance (1 in 6 = 16.7%). The dataset appears synthetic, "
            "so its fields carry no information about the condition.")
