"""
test.py  -  STEP 2: evaluate the trained model on the unseen test split
and build results/report.html (all tables + graphs in one page).
Run:  python test.py      (after python train.py)
"""
import base64
import glob
import os
import warnings
warnings.filterwarnings("ignore")

import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (accuracy_score, classification_report, confusion_matrix,
                             f1_score, precision_score, recall_score)

sns.set_style("whitegrid")
TARGET = "Medical Condition"
FEATURES = ["Gender", "Blood Type", "Insurance Provider", "Admission Type", "Medication",
            "Test Results", "Age", "Billing Amount", "Length of Stay", "Admission Month"]

model = joblib.load("model.pkl")
test = pd.read_csv("test_split.csv")
proba = model.predict_proba(test[FEATURES])
test["Predicted"] = model.classes_[proba.argmax(axis=1)]
test["Confidence"] = proba.max(axis=1).round(4)
y, p = test[TARGET], test["Predicted"]
labels = sorted(y.unique())


def show(title, table):
    print(f"\n=== {title} ===")
    print(table.to_string(index=False))
    table.to_csv("results/" + title.lower().replace(" ", "_") + ".csv", index=False)


def savefig(name):
    plt.tight_layout(); plt.savefig(f"results/{name}", dpi=110, bbox_inches="tight"); plt.close()
    print(f"[Chart saved] results/{name}")


# ---------- tables ----------
show("Test Metrics", pd.DataFrame({
    "metric": ["Test rows", "Accuracy", "Macro precision", "Macro recall", "Macro F1",
               "Chance level (1/6)", "Mean confidence"],
    "value": [len(test), round(accuracy_score(y, p), 4),
              round(precision_score(y, p, average="macro"), 4),
              round(recall_score(y, p, average="macro"), 4),
              round(f1_score(y, p, average="macro"), 4),
              round(1 / len(labels), 4), round(test["Confidence"].mean(), 4)]}))

rep = pd.DataFrame(classification_report(y, p, output_dict=True, zero_division=0)).T.round(3)
rep = rep.reset_index().rename(columns={"index": "class"})
show("Classification Report", rep)

cm = pd.DataFrame(confusion_matrix(y, p, labels=labels), index=labels, columns=labels)
show("Confusion Matrix", cm.reset_index().rename(columns={"index": "actual \\ predicted"}))

sample = test[["Name", "Age", "Gender", "Medication", "Admission Type", TARGET, "Predicted", "Confidence"]].head(15)
sample["Correct"] = np.where(sample[TARGET] == sample["Predicted"], "Yes", "No")
show("Sample Predictions", sample)

wrong = (y != p).sum()
show("Correct vs Wrong", pd.DataFrame({"result": ["Correct", "Wrong"], "count": [len(y) - wrong, wrong],
                                       "%": [round((len(y) - wrong) / len(y) * 100, 1), round(wrong / len(y) * 100, 1)]}))

# ---------- graphs ----------
fig, ax = plt.subplots(1, 2, figsize=(16, 6.5))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=ax[0]); ax[0].set_title("Confusion Matrix (counts)")
sns.heatmap(cm.div(cm.sum(axis=1), axis=0), annot=True, fmt=".2f", cmap="Greens", ax=ax[1])
ax[1].set_title("Confusion Matrix (row-normalised)")
for a in ax: a.set_xlabel("Predicted"); a.set_ylabel("Actual"); plt.setp(a.get_xticklabels(), rotation=30)
savefig("test_confusion_matrix.png")

per = rep[rep["class"].isin(labels)].melt(id_vars="class", value_vars=["precision", "recall", "f1-score"])
plt.figure(figsize=(11, 6))
sns.barplot(data=per, x="value", y="class", hue="variable", palette="Set2")
plt.axvline(1 / len(labels), color="red", ls="--", label="Chance"); plt.xlim(0, 0.5); plt.legend()
plt.title("Precision / Recall / F1 per Condition (test set)", fontweight="bold"); plt.ylabel("")
savefig("test_per_class_scores.png")

fig, ax = plt.subplots(1, 2, figsize=(15, 5))
cmp = pd.DataFrame({"Actual": y.value_counts(), "Predicted": p.value_counts()}).reindex(labels)
cmp.plot.bar(ax=ax[0], color=["#4C72B0", "#DD8452"]); ax[0].set_title("Actual vs Predicted Counts")
plt.setp(ax[0].get_xticklabels(), rotation=25)
sns.histplot(test["Confidence"], bins=30, color="#55A868", ax=ax[1]); ax[1].set_title("Prediction Confidence")
savefig("test_actual_vs_predicted.png")

# ---------- HTML report ----------
def img(f, cap):
    b = base64.b64encode(open(f, "rb").read()).decode()
    return f'<figure><img src="data:image/png;base64,{b}"><figcaption>{cap}</figcaption></figure>'


def tab(csv):
    return pd.read_csv(f"results/{csv}.csv").to_html(index=False, border=0, na_rep="")


sections = [
    ("1. Workflow", img("results/diagram_workflow.png", "Project workflow")),
    ("2. Data", tab("dataset_overview") + tab("cleaning_log") + tab("numeric_summary") + tab("class_distribution")
                + img("results/eda.png", "Exploratory analysis") + img("results/eda_condition_details.png", "Condition details")),
    ("3. Training", tab("train_test_split") + tab("best_hyperparameters") + tab("model_comparison")
                    + img("results/model_comparison.png", "Model comparison") + tab("cross_validation")
                    + img("results/cv_scores.png", "Cross-validation") + tab("top_feature_importances")
                    + img("results/feature_importance.png", "Feature importance")),
    ("4. Testing", tab("test_metrics") + tab("classification_report") + tab("confusion_matrix")
                   + img("results/test_confusion_matrix.png", "Confusion matrices")
                   + img("results/test_per_class_scores.png", "Per-class scores")
                   + img("results/test_actual_vs_predicted.png", "Actual vs predicted") + tab("correct_vs_wrong")),
    ("5. Sample predictions", tab("sample_predictions")),
]
html = """<!doctype html><html><head><meta charset="utf-8"><title>HealthCareAI Results</title><style>
body{font-family:Segoe UI,Arial,sans-serif;max-width:1000px;margin:30px auto;color:#222}
h1,h2{color:#1F3A5F}h2{border-bottom:2px solid #1F3A5F;padding-bottom:4px;margin-top:36px}
table{border-collapse:collapse;width:100%;margin:12px 0;font-size:.9em}th{background:#1F3A5F;color:#fff;padding:6px;text-align:left}
td{padding:5px 6px;border-bottom:1px solid #ddd}img{max-width:100%}figcaption{color:#555;font-size:.85em}
.note{background:#fff7e6;border-left:4px solid #e0a100;padding:10px 14px}</style></head><body>
<h1>HealthCareAI - Results</h1>
<div class="note"><b>Key finding:</b> test accuracy is close to chance (1 in 6 = 16.7%). The dataset appears to be
synthetic, so the available fields do not carry information about the medical condition.</div>"""
for title, body in sections:
    html += f"<h2>{title}</h2>{body}"
open("results/report.html", "w", encoding="utf-8").write(html + "</body></html>")
print("\nReport saved: results/report.html")
